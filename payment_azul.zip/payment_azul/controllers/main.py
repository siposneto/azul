# -*- coding: utf-8 -*-
import logging
import pprint
from odoo import http
from odoo.http import request

_logger = logging.getLogger(__name__)


class AzulController(http.Controller):

    @http.route('/payment/azul/return', type='http', auth='public',
                methods=['GET', 'POST'], csrf=False, save_session=False)
    def azul_return(self, **data):
        _logger.info('AZUL /return:\n%s', pprint.pformat(data))
        if data:
            try:
                request.env['payment.transaction'].sudo()._handle_notification_data('azul', data)
            except Exception as e:
                _logger.exception('AZUL /return error: %s', e)
        return request.redirect('/payment/status')

    @http.route('/payment/azul/cancel', type='http', auth='public',
                methods=['GET', 'POST'], csrf=False, save_session=False)
    def azul_cancel(self, **data):
        _logger.info('AZUL /cancel:\n%s', pprint.pformat(data))
        ref = data.get('OrderNumber')
        if ref:
            try:
                tx = request.env['payment.transaction'].sudo().search([
                    ('reference', '=', ref), ('provider_code', '=', 'azul'),
                ], limit=1)
                if tx:
                    tx._set_canceled()
            except Exception as e:
                _logger.exception('AZUL /cancel error: %s', e)
        return request.redirect('/payment/status')
