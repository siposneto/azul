# -*- coding: utf-8 -*-
from . import controllers
from . import models

from odoo.addons.payment import setup_provider, reset_payment_provider


def post_init_hook(env):
    setup_provider(env, 'azul')

    # Garantizar que los métodos de pago estén vinculados al proveedor AZUL.
    # Si setup_provider no encontró el método 'card', lo vinculamos manualmente.
    provider = env['payment.provider'].search([('code', '=', 'azul')], limit=1)
    if not provider:
        return

    if not provider.payment_method_ids:
        # Buscar métodos de pago por código en orden de prioridad
        method_codes = ['card', 'visa', 'mastercard']
        methods = env['payment.method'].search([('code', 'in', method_codes)])
        if methods:
            provider.write({'payment_method_ids': [(4, m.id) for m in methods]})
        else:
            # Último recurso: vincular TODOS los métodos disponibles
            all_methods = env['payment.method'].search([])
            if all_methods:
                provider.write({'payment_method_ids': [(4, m.id) for m in all_methods]})


def uninstall_hook(env):
    reset_payment_provider(env, 'azul')
