# -*- coding: utf-8 -*-
import hashlib
import hmac
import logging

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

_logger = logging.getLogger(__name__)

# URLs por defecto — también configurables desde el formulario del proveedor
AZUL_URL_PROD = 'https://pagos.azul.com.do/PaymentPage/Default.aspx'
AZUL_URL_ALT  = 'https://contpagos.azul.com.do/PaymentPage/Default.aspx'
AZUL_URL_TEST = 'https://pruebas.azul.com.do/PaymentPage/Default.aspx'


class PaymentProvider(models.Model):
    _inherit = 'payment.provider'

    code = fields.Selection(
        selection_add=[('azul', 'AZUL')],
        ondelete={'azul': 'set default'},
    )

    # ── Credenciales ─────────────────────────────────────────────
    azul_merchant_id = fields.Char(
        string='Merchant ID',
        default='39038540035',
        help='Canal de pago proporcionado por AZUL.',
    )
    azul_merchant_name = fields.Char(
        string='Nombre del Comercio',
        default='TEST_STORE',
        help='Aparece en la página de pago. Máx. 30 chars. Sin comillas ni barras.',
    )
    azul_merchant_type = fields.Char(
        string='Merchant Type',
        default='CCS',
        help='Tipo de comercio (ej. CCS, ECommerce). Proporcionado por AZUL.',
    )
    azul_auth_key = fields.Char(
        string='Auth Key',
        help='Clave secreta HMAC-SHA512 proporcionada por AZUL. Nunca se transmite en el POST.',
        groups='base.group_system',
        copy=False,
    )
    azul_currency_code = fields.Char(
        string='Código de Moneda',
        default='214',
        help='214 = DOP (Peso Dominicano).',
    )
    azul_alt_merchant_name = fields.Char(
        string='Nombre Alterno (Estado de Cuenta)',
        help='Nombre en el estado de cuenta del tarjetahabiente. Máx. 25 chars.',
    )

    # ── URLs configurables (tomadas del módulo oficial) ───────────
    azul_payment_test_url = fields.Char(
        string='URL de Pruebas',
        default='https://pruebas.azul.com.do/PaymentPage/Default.aspx',
        help='URL de la página de pagos en ambiente de pruebas.',
    )
    azul_payment_prod_url = fields.Char(
        string='URL de Producción',
        default='https://pagos.azul.com.do/PaymentPage/Default.aspx',
        help='URL principal de la página de pagos en producción.',
    )
    azul_payment_alt_url = fields.Char(
        string='URL de Contingencia',
        default='https://contpagos.azul.com.do/PaymentPage/Default.aspx',
        help='URL de respaldo si la URL principal falla. Requerida por la spec AZUL.',
    )

    # ── Opciones de Transacción ───────────────────────────────────
    azul_trx_type = fields.Selection(
        selection=[('Sale', 'Sale (cargo inmediato)'), ('Hold', 'Hold (pre-autorización)')],
        string='Tipo de Transacción',
        default='Sale',
    )
    azul_locale = fields.Selection(
        selection=[('ES', 'Español'), ('EN', 'English')],
        string='Idioma',
        default='ES',
    )
    azul_show_transaction_result = fields.Selection(
        selection=[('1', 'Sí'), ('0', 'No')],
        string='Mostrar Resultado AZUL',
        default='1',
    )
    azul_save_to_datavault = fields.Boolean(
        string='Tokenizar Tarjeta (DataVault)',
        default=False,
    )
    azul_use_installments = fields.Boolean(
        string='Habilitar Cuotas',
        default=False,
    )
    azul_max_installments = fields.Integer(
        string='Máximo de Cuotas',
        default=3,
    )

    # ── Campos Personalizados ─────────────────────────────────────
    azul_custom_field1_label = fields.Char(string='Campo Personalizado 1 – Etiqueta')
    azul_custom_field1_value = fields.Char(string='Campo Personalizado 1 – Valor')
    azul_custom_field2_label = fields.Char(string='Campo Personalizado 2 – Etiqueta')
    azul_custom_field2_value = fields.Char(string='Campo Personalizado 2 – Valor')

    # ── Odoo payment API ──────────────────────────────────────────

    def _get_default_payment_method_codes(self):
        self.ensure_one()
        if self.code != 'azul':
            return super()._get_default_payment_method_codes()
        return {'card'}

    def _compute_feature_support_fields(self):
        super()._compute_feature_support_fields()
        self.filtered(lambda p: p.code == 'azul').update({
            'support_tokenization': False,
            'support_manual_capture': False,
            'support_refund': False,
        })

    # ── URLs ──────────────────────────────────────────────────────

    def _azul_get_api_url(self):
        """URL principal según el estado del proveedor."""
        self.ensure_one()
        if self.state == 'test':
            return self.azul_payment_test_url or AZUL_URL_TEST
        return self.azul_payment_prod_url or AZUL_URL_PROD

    def _azul_get_alt_url(self):
        """URL de contingencia según el estado del proveedor."""
        self.ensure_one()
        if self.state == 'test':
            return self.azul_payment_test_url or AZUL_URL_TEST
        return self.azul_payment_alt_url or AZUL_URL_ALT

    # ── Hash HMAC-SHA512 UTF-16LE (según spec oficial AZUL) ───────

    @staticmethod
    def _azul_hmac(auth_key, message):
        """
        HMAC-SHA512 con codificación UTF-16LE.
        Equivalente en PHP:
            mb_convert_encoding($string, 'UTF-16LE', 'ASCII')
            hash_hmac('sha512', $string, $authKey)
        Equivalente en C#:
            Encoding.Unicode.GetBytes(all.ToString())
            HMACSHA512.ComputeHash(bytes)
        """
        return hmac.new(
            auth_key.encode('utf-16-le'),
            message.encode('utf-16-le'),
            hashlib.sha512,
        ).hexdigest().upper()

    def _azul_request_hash(self, p):
        """
        AuthHash del REQUEST. Orden exacto según spec AZUL:
        MerchantId + MerchantName + MerchantType + CurrencyCode +
        OrderNumber + Amount + ITBIS + ApprovedUrl + DeclinedUrl + CancelUrl +
        UseCustomField1 + CustomField1Label + CustomField1Value +
        UseCustomField2 + CustomField2Label + CustomField2Value + AuthKey
        """
        self.ensure_one()
        msg = (
            p.get('MerchantId', '')
            + p.get('MerchantName', '')
            + p.get('MerchantType', '')
            + p.get('CurrencyCode', '')
            + p.get('OrderNumber', '')
            + p.get('Amount', '')
            + p.get('ITBIS', '')
            + p.get('ApprovedUrl', '')
            + p.get('DeclinedUrl', '')
            + p.get('CancelUrl', '')
            + p.get('UseCustomField1', '')
            + p.get('CustomField1Label', '')
            + p.get('CustomField1Value', '')
            + p.get('UseCustomField2', '')
            + p.get('CustomField2Label', '')
            + p.get('CustomField2Value', '')
            + (self.azul_auth_key or '')
        )
        return self._azul_hmac(self.azul_auth_key or '', msg)

    def _azul_response_hash_valid(self, data):
        """
        Valida el AuthHash de la RESPUESTA. Orden exacto según spec AZUL:
        OrderNumber + Amount + AuthorizationCode + DateTime + ResponseCode +
        ISOCode + ResponseMessage + ErrorDescription + RRN + AuthKey
        """
        self.ensure_one()
        received = data.get('AuthHash', '')
        auth_key = self.azul_auth_key or ''
        if not received or not auth_key:
            _logger.warning('AZUL: hash o auth_key vacío en la respuesta.')
            return False
        msg = (
            data.get('OrderNumber', '')
            + data.get('Amount', '')
            + data.get('AuthorizationCode', '')
            + data.get('DateTime', '')
            + data.get('ResponseCode', '')
            + data.get('IsoCode', '')
            + data.get('ResponseMessage', '')
            + data.get('ErrorDescription', '')
            + data.get('RRN', '')
            + auth_key
        )
        expected = self._azul_hmac(auth_key, msg)
        match = hmac.compare_digest(expected, received.upper())
        if not match:
            _logger.warning('AZUL: hash inválido. Esperado=%s Recibido=%s',
                            expected, received.upper())
        return match

    # ── ITBIS desde la orden de venta ─────────────────────────────

    def _azul_get_itbis(self, tx):
        """
        Obtiene el ITBIS real de la orden de venta.
        Tomado del módulo oficial: busca la SO por referencia y usa amount_tax.
        Formato AZUL: entero × 100 sin decimales (1800 = 18.00).
        Si no hay SO (ej. pago de factura), devuelve '000'.
        """
        try:
            so_name = tx.reference.split('-')[0] if '-' in tx.reference else tx.reference
            so_name = so_name.split('/')[0]
            sale_order = self.env['sale.order'].search([('name', '=', so_name)], limit=1)
            if sale_order and sale_order.amount_tax:
                return str(int(round(sale_order.amount_tax * 100)))
        except Exception as e:
            _logger.warning('AZUL: No se pudo obtener ITBIS de la SO: %s', e)
        return '000'

    # ── Valores del formulario POST ───────────────────────────────

    def _azul_get_redirect_form_values(self, tx, base_url):
        """
        Construye el dict completo de campos para el POST a la Página de Pago AZUL.
        El AuthHash se calcula al final, después de tener todos los campos.
        """
        self.ensure_one()
        return_url = '%s/payment/azul/return' % base_url
        cancel_url = '%s/payment/azul/cancel' % base_url
        amount_str = str(int(round(tx.amount * 100)))
        itbis_str  = self._azul_get_itbis(tx)

        use_cf1 = '1' if (self.azul_custom_field1_label or self.azul_custom_field1_value) else '0'
        use_cf2 = '1' if (self.azul_custom_field2_label or self.azul_custom_field2_value) else '0'

        p = {
            'MerchantId':            self.azul_merchant_id or '',
            'MerchantName':          (self.azul_merchant_name or '')[:30],
            'MerchantType':          self.azul_merchant_type or 'CCS',
            'CurrencyCode':          self.azul_currency_code or '214',
            'OrderNumber':           tx.reference,
            'Amount':                amount_str,
            'ITBIS':                 itbis_str,
            'ApprovedUrl':           return_url,
            'DeclinedUrl':           return_url,
            'CancelUrl':             cancel_url,
            'UseCustomField1':       use_cf1,
            'CustomField1Label':     self.azul_custom_field1_label or '',
            'CustomField1Value':     self.azul_custom_field1_value or '',
            'UseCustomField2':       use_cf2,
            'CustomField2Label':     self.azul_custom_field2_label or '',
            'CustomField2Value':     self.azul_custom_field2_value or '',
            'TrxType':               self.azul_trx_type or 'Sale',
            'ShowTransactionResult': self.azul_show_transaction_result or '1',
            'Locale':                self.azul_locale or 'ES',
            'SaveToDataVault':       '1' if self.azul_save_to_datavault else '0',
        }

        if self.azul_use_installments and self.azul_max_installments > 1:
            p['Installments'] = str(self.azul_max_installments)
        if self.azul_alt_merchant_name:
            p['AltMerchantName'] = self.azul_alt_merchant_name[:25]

        # AuthHash SIEMPRE al final
        p['AuthHash']    = self._azul_request_hash(p)
        p['api_url']     = self._azul_get_api_url()
        p['api_url_alt'] = self._azul_get_alt_url()
        return p

    # ── Validaciones ─────────────────────────────────────────────

    @api.constrains('azul_merchant_name')
    def _check_merchant_name(self):
        for r in self.filtered(lambda x: x.code == 'azul' and x.azul_merchant_name):
            if any(c in r.azul_merchant_name for c in ('"', "'", '\\')):
                raise ValidationError(_(
                    'Nombre del Comercio: no puede contener comillas ( " \' ) ni barras ( \\ ).'
                ))
            if len(r.azul_merchant_name) > 30:
                raise ValidationError(_('Nombre del Comercio: máximo 30 caracteres.'))

    @api.constrains('azul_alt_merchant_name')
    def _check_alt_merchant_name(self):
        for r in self.filtered(lambda x: x.code == 'azul' and x.azul_alt_merchant_name):
            if any(c in r.azul_alt_merchant_name for c in ('"', "'", '\\')):
                raise ValidationError(_(
                    'Nombre Alterno: no puede contener comillas ( " \' ) ni barras ( \\ ).'
                ))
            if len(r.azul_alt_merchant_name) > 25:
                raise ValidationError(_('Nombre Alterno: máximo 25 caracteres.'))
