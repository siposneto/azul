# -*- coding: utf-8 -*-
{
    'name': 'Payment Provider: AZUL',
    'version': '1.0',
    'category': 'Accounting/Payment Providers',
    'sequence': 350,
    'summary': 'AZUL - Servicios Digitales Popular (República Dominicana)',
    'description': ' ',
    'depends': ['payment'],
    'data': [
        'views/payment_provider_views.xml',
        'views/payment_azul_templates.xml',
        'data/payment_provider_data.xml',
    ],
    'post_init_hook': 'post_init_hook',
    'uninstall_hook': 'uninstall_hook',
    'assets': {
        'web.assets_frontend': [
            'payment_azul/static/src/css/payment_azul.css',
            'payment_azul/static/src/js/payment_azul.js',
        ],
    },
    'author': 'Custom Development',
    'license': 'LGPL-3',
    'installable': True,
    'auto_install': False,
    'application': False,
}
