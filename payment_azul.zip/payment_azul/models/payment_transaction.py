# -*- coding: utf-8 -*-
import logging
import pprint
import datetime

from odoo import _, api, fields, models
from odoo.exceptions import ValidationError

_logger = logging.getLogger(__name__)


class PaymentTransaction(models.Model):
    _inherit = 'payment.transaction'

    # ── Campos de respuesta AZUL ──────────────────────────────────
    azul_order_id           = fields.Char(string='AZUL Order ID',            readonly=True, copy=False)
    azul_authorization_code = fields.Char(string='Código de Autorización',   readonly=True, copy=False)
    azul_rrn                = fields.Char(string='RRN',                       readonly=True, copy=False)
    azul_iso_code           = fields.Char(string='ISO Code',                  readonly=True, copy=False)
    azul_response_code      = fields.Char(string='Response Code',             readonly=True, copy=False)
    azul_response_message   = fields.Char(string='Mensaje de Respuesta',      readonly=True, copy=False)
    azul_error_description  = fields.Char(string='Descripción de Error',      readonly=True, copy=False)
    azul_datetime           = fields.Char(string='Fecha/Hora AZUL',           readonly=True, copy=False)
    azul_datavault_token    = fields.Char(string='DataVault Token',           readonly=True, copy=False)
    azul_datavault_expiry   = fields.Char(string='DataVault Expiración',      readonly=True, copy=False)
    azul_datavault_brand    = fields.Char(string='DataVault Marca',           readonly=True, copy=False)

    # ── Rendering: devuelve todos los valores al template ─────────

    def _get_specific_rendering_values(self, processing_values):
        """
        Override para Odoo 19.
        Odoo llama a este método y pasa el resultado como 'rendering_values'
        al template QWeb del formulario de redirección.
        Devolvemos TODOS los campos del POST incluyendo AuthHash y api_url.
        """
        res = super()._get_specific_rendering_values(processing_values)
        if self.provider_code != 'azul':
            return res
        base_url = self.provider_id.get_base_url()
        return self.provider_id._azul_get_redirect_form_values(self, base_url)

    # ── Buscar transacción desde la notificación ──────────────────

    @api.model
    def _get_tx_from_notification_data(self, provider_code, notification_data):
        tx = super()._get_tx_from_notification_data(provider_code, notification_data)
        if provider_code != 'azul' or len(tx) == 1:
            return tx

        reference = notification_data.get('OrderNumber')
        if not reference:
            raise ValidationError(_('AZUL: No se recibió el parámetro OrderNumber.'))

        tx = self.search([
            ('reference', '=', reference),
            ('provider_code', '=', 'azul'),
        ])
        if not tx:
            raise ValidationError(
                _('AZUL: No se encontró transacción para OrderNumber: %s') % reference
            )
        return tx

    # ── Procesar notificación de AZUL ─────────────────────────────

    def _process_notification_data(self, notification_data):
        super()._process_notification_data(notification_data)
        if self.provider_code != 'azul':
            return

        _logger.info('AZUL notificación [%s]:\n%s',
                     self.reference, pprint.pformat(notification_data))

        # 1. Verificar el hash de autenticación de la respuesta
        if not self.provider_id._azul_response_hash_valid(notification_data):
            _logger.warning('AZUL: Hash inválido para tx %s', self.reference)
            self._set_error(_('AZUL: Firma de respuesta inválida.'))
            return

        # 2. Guardar todos los campos de respuesta
        self.write({
            'azul_order_id':           notification_data.get('OrderNumber', ''),
            'azul_authorization_code': notification_data.get('AuthorizationCode', ''),
            'azul_rrn':                notification_data.get('RRN', ''),
            'azul_iso_code':           notification_data.get('IsoCode', ''),
            'azul_response_code':      notification_data.get('ResponseCode', ''),
            'azul_response_message':   notification_data.get('ResponseMessage', ''),
            'azul_error_description':  notification_data.get('ErrorDescription', ''),
            'azul_datetime':           notification_data.get('DateTime', ''),
            'azul_datavault_token':    notification_data.get('DataVaultToken', ''),
            'azul_datavault_expiry':   notification_data.get('DataVaultExpiration', ''),
            'azul_datavault_brand':    notification_data.get('DataVaultBrand', ''),
        })

        # 3. Parsear fecha de AZUL (formato: YYYYMMDDHHmmss → 20190530051103)
        azul_dt = notification_data.get('DateTime', '')
        if azul_dt and len(azul_dt) >= 14:
            try:
                parsed_dt = datetime.datetime(
                    int(azul_dt[0:4]),  int(azul_dt[4:6]),  int(azul_dt[6:8]),
                    int(azul_dt[8:10]), int(azul_dt[10:12]), int(azul_dt[12:14]),
                )
                self.write({'last_state_change': parsed_dt})
            except Exception:
                pass

        # 4. Determinar el estado final
        iso_code      = notification_data.get('IsoCode', '')
        response_code = notification_data.get('ResponseCode', '')
        error_desc    = notification_data.get('ErrorDescription', '')
        resp_msg      = notification_data.get('ResponseMessage', '')

        if iso_code == '00':
            self.provider_reference = (
                notification_data.get('AuthorizationCode') or
                notification_data.get('RRN', '')
            )
            _logger.info('AZUL: tx %s APROBADA. AuthCode=%s',
                         self.reference, self.provider_reference)
            self._set_done()

        elif (response_code or '').upper() == 'CANCEL':
            _logger.info('AZUL: tx %s CANCELADA por el usuario.', self.reference)
            self._set_canceled()

        else:
            error_msg = error_desc or resp_msg or _('Transacción rechazada.')
            _logger.warning('AZUL: tx %s RECHAZADA. IsoCode=%s Mensaje=%s',
                            self.reference, iso_code, error_msg)
            self._set_error('AZUL [IsoCode %s]: %s' % (iso_code, error_msg))
