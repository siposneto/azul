(function(){
    'use strict';
    function init(){
        var form=document.getElementById('azul_redirect_form');
        if(!form)return;
        var altEl=document.getElementById('azul_alt_url');
        var btn=document.getElementById('azul_manual_btn');
        var primary=form.action, alt=altEl?altEl.value:primary;
        setTimeout(function(){
            try{form.submit();}catch(e){
                if(alt&&alt!==primary){form.action=alt;try{form.submit();}catch(e2){}}
            }
        },400);
        setTimeout(function(){if(btn)btn.style.display='inline-block';},8000);
        if(btn)btn.addEventListener('click',function(){form.submit();});
    }
    document.readyState==='loading'?document.addEventListener('DOMContentLoaded',init):init();
}());
